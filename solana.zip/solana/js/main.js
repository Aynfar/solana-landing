(function($) {
  "use strict"; // Start of use strict

  $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: (target.offset().top - 54)
        }, 1000, "easeInOutExpo");
        return false;
      }
    }
  });

  $(window).on("scroll", function () {
    if ($(this).scrollTop() > 100) {
      $("#show-top").addClass( "show-top" );
    }
    else {
      $("#show-top").removeClass( "show-top" );    
    }
  });

  var current_width = $(window).width();


  


  // menu sticky
  $(window).on("scroll", function () {
    if(current_width > 992){
      
      $(".navbar-collapse").addClass( "show" );

      if ($(this).scrollTop() > 1) {
        $("header").addClass( "sticky" );
      }
      else {
        $("header").removeClass( "sticky" );     
      }
    }
    else{
      if ($(this).scrollTop() > 1) {
        $("header").addClass( "sticky-mobile" );
      }
      else {
        $("header").removeClass( "sticky-mobile" );     
      }
    }
  });


  $( document ).ready(function() {
    if(current_width > 992){
        
      $(".navbar-collapse").addClass( "push-right" );
    }
    else{
      
      $(".navbar-collapse").removeClass( "push-right" );
    }
  });
  

  $(".list-toggle").click(function(event) {
    event.preventDefault();
    $(this).next("ul.inner").slideToggle();
    
  });


  // remove And add

  if(current_width > 1200){
    $(".dropdown-menu").removeAttr('style')
    $(".dropdown").hover(function(){
        var dropdownMenu = $(this).children(".dropdown-menu");
        if(dropdownMenu.is(":visible")){
            dropdownMenu.parent().toggleClass("open");
        }
    });
  }


    // dropdown responsive

    if(current_width < 992){

      $(".dropdown .icon").click(function(event) {

        $(this).toggleClass('open');

        $(this).next().toggle();

      });

    }



  
    $("#certifications").owlCarousel({
      dots: true,
      responsiveClass: false,
      loop: true,
      autoplay: true,
      slideTransition: 'linear',
      autoplayTimeout: 3500,
      autoplaySpeed: 3500,
      // navText: ['<i class="fa fa-angle-left" aria-hidden="true"></i>', '<i class="fa fa-angle-right" aria-hidden="true"></i>'],
      nav: false,
      responsive: {
        0: {
          items:2 
        },
        600: {
          items: 4
        },
        1000: {
          items: 5
        }
      }
    });

    
    

  // counter js



  $('.counter').each(function () {
    $(this).prop('Counter', 0).animate({
        Counter: parseFloat($(this).text().replace(/,/g, ''))
    }, {
        duration: 2000,
        easing: 'swing',
        step: function (now) {
            $(this).text(parseFloat(now).toFixed(1).toLocaleString());
        }
    });
});
document.addEventListener("DOMContentLoaded", function () {
 
  function scrollTextAnimation() {
   
    var scrollTextElement = document.querySelector('.scroll-text');

   
    scrollTextElement.classList.add('scrolling');
  }

 
  setTimeout(scrollTextAnimation, 1000); // 1000 milliseconds = 1 second
});


  
  $(".filestyle").filestyle({placeholder: "Upload File"});

})(jQuery); // End of use strict
